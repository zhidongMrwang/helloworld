<template>
  <div class="split"></div>
</template>

<script type="text/ecmascript-6">
  export default {

  }
</script>

<style lang="stylus" type="text/stylus">
  .split
    border-top :1px solid rgba(7,17,27,0.1)
    height 16px
    width :100%
    border-bottom :1px solid rgba(7,17,27,0.1)
    background :#f3f5f7
</style>
